export const environment = {
  production: true,  
  APIHOST: "https://thdnodeservice.mybluemix.net/"
};
