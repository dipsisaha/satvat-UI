import { environment } from '../environments/environment';
export class ApplicationSettings {
	public static API_ENDPOINT = environment.APIHOST +'api';
	public static CHAIN_CODE_ID = "thdpoc_cc";
	public static CHAIN_CODE_USERNAME = "THDAssociate7";
}