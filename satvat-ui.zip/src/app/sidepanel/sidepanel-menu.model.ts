export class Menu {
    constructor(public id: string, public description: string, public link: string, public icon: string) { }
}