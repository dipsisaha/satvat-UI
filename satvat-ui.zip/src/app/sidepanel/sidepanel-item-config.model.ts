export class ItemConfig {
    constructor(public panelId: string, public title: string, public component: string) { };
}