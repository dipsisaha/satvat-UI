export class Menu {
    constructor(public id: number, public description: string, public link: string, public icon: string) { }
}