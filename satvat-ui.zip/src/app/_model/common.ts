export interface CommonList {
    Name:string
}