
export class SidePanelData{
    constructor(public showSidePanel:boolean,public orgId:string,public panelId:string,public stateURL:string){};
}