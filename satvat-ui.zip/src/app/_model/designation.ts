export interface DesignationList {
    Name:string,
    Short_Name:string

}