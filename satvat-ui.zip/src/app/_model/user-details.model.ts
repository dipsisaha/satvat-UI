export class UserDetails {  
   
    constructor() {
       
    }
}