
export class NavbarData{
    constructor(public showNav:boolean,public orgId:string,public roleId:string,public username:string,public stateURL:string){};
}